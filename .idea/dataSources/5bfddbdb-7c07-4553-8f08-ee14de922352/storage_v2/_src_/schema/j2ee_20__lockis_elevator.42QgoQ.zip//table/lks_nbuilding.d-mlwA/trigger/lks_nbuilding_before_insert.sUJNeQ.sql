create trigger lks_NBuilding_BEFORE_INSERT
  before INSERT
  on lks_nbuilding
  for each row
  BEGIN
SET NEW.`reference` = UUID();
END;

