create trigger lke_nbutton_settings_BEFORE_UPDATE
  before UPDATE
  on lks_nbutton_settings
  for each row
  BEGIN
SET NEW.`revised`=CURRENT_TIMESTAMP;
END;

