create trigger lks_xException_BEFORE_INSERT
  before INSERT
  on lks_xexception
  for each row
  BEGIN
SET NEW.`reference` = UUID();
END;

