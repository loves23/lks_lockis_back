create trigger lke_nbutton_settings_BEFORE_INSERT
  before INSERT
  on lks_nbutton_settings
  for each row
  BEGIN
SET NEW.`reference` = UUID();
END;

