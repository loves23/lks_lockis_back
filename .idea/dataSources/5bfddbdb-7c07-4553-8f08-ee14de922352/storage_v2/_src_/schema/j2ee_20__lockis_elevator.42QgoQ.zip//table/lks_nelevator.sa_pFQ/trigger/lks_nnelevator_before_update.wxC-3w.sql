create trigger lks_NNelevator_BEFORE_UPDATE
  before UPDATE
  on lks_nelevator
  for each row
  BEGIN
SET NEW.`revised`=CURRENT_TIMESTAMP;
END;

