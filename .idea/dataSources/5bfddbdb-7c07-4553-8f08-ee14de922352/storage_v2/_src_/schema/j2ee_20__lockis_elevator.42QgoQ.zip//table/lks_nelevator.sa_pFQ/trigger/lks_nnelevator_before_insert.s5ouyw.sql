create trigger lks_NNelevator_BEFORE_INSERT
  before INSERT
  on lks_nelevator
  for each row
  BEGIN
SET NEW.`reference` = UUID();
END;

