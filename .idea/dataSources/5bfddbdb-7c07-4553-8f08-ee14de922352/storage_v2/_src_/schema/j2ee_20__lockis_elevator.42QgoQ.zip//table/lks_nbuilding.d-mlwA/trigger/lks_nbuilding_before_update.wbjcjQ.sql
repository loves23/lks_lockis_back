create trigger lks_NBuilding_BEFORE_UPDATE
  before UPDATE
  on lks_nbuilding
  for each row
  BEGIN
SET NEW.`revised`=CURRENT_TIMESTAMP;
END;

